# Framework agreements

```eval_rst
.. admonition:: Note
    :class: note

    .. markdown::

      The approach for modelling framework agreements in OCDS is under discussion ([GitHub issue](https://github.com/open-contracting/standard/issues/440)).

```
