# History

The [Changelog](changelog) describes what's new in each version of OCDS. [Development and Appreciation](history_and_development) describes the development of early versions of OCDS, and thanks all contributors.

```eval_rst
.. toctree::
   :hidden:

   changelog
   history_and_development
```
